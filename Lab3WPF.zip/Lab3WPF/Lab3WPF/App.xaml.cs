using System.Windows;

namespace Lab3WPF
{
    public partial class App : Application
    {
    }
}
