using Microsoft.EntityFrameworkCore;
using Lab3WPF.Models;

namespace Lab3WPF.Data
{
    /// <summary>
    /// Контекст базы данных Entity Framework Core.
    /// Подключается к SQL Server LocalDB.
    /// Строка подключения: (localdb)\MSSQLLocalDB, база Lab3DB.
    /// </summary>
    public class AppDbContext : DbContext
    {
        public DbSet<Order> Orders { get; set; } = null!;

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            // SQL Server LocalDB — не требует отдельной установки SQL Server,
            // входит в состав Visual Studio.
            optionsBuilder.UseSqlServer(
                @"Server=(localdb)\MSSQLLocalDB;Database=Lab3DB;Trusted_Connection=True;");
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Order>(entity =>
            {
                entity.ToTable("Orders");
                entity.HasKey(e => e.Id);

                entity.Property(e => e.КодЗаказа)   .HasMaxLength(50) .IsRequired();
                entity.Property(e => e.ДатаСоздания).HasMaxLength(20) .IsRequired();
                entity.Property(e => e.КодКлиента)  .HasMaxLength(50) .IsRequired();
                entity.Property(e => e.Услуги)       .HasMaxLength(200).IsRequired();
            });
        }
    }
}
