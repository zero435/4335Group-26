using System;
using System.Collections.Generic;
using System.IO;
using System.Windows;
using Microsoft.Win32;
using Lab3WPF.Models;
using Lab3WPF.Services;

namespace Lab3WPF
{
    /// <summary>
    /// Главное окно: 4335_ЛабораторнаяРабота3, Вариант 3.
    /// Импорт из 3.xlsx → MSSQL LocalDB.
    /// Экспорт в Excel с группировкой по дате создания заказа.
    /// </summary>
    public partial class MainWindow : Window
    {
        private readonly ExcelService    _excelService    = new();
        private readonly DatabaseService _databaseService = new();

        private List<Order> _orders = new();

        public MainWindow()
        {
            InitializeComponent();
            InitializeDatabase();
        }

        /// <summary>
        /// Создаёт базу данных и таблицу при первом запуске приложения.
        /// </summary>
        private void InitializeDatabase()
        {
            try
            {
                _databaseService.EnsureDatabaseCreated();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    $"Не удалось подключиться к SQL Server LocalDB:\n\n{ex.Message}\n\n" +
                    "Убедитесь, что установлен SQL Server LocalDB (входит в Visual Studio).",
                    "Ошибка подключения к БД",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
            }
        }

        // ──────────────────────────────────────────────────────────────────────
        //  ИМПОРТ ДАННЫХ
        // ──────────────────────────────────────────────────────────────────────

        private void BtnImport_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new OpenFileDialog
            {
                Title    = "Выберите файл 3.xlsx",
                Filter   = "Excel файлы (*.xlsx)|*.xlsx|Все файлы (*.*)|*.*",
                FileName = "3.xlsx"
            };

            if (dialog.ShowDialog() != true) return;

            try
            {
                SetStatus("Импорт данных...");
                BtnImport.IsEnabled = false;

                // 1. Читаем данные из Excel
                var imported = _excelService.ImportFromExcel(dialog.FileName);

                if (imported.Count == 0)
                {
                    MessageBox.Show("Файл не содержит данных.", "Предупреждение",
                        MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                // 2. Сохраняем в MSSQL
                _databaseService.SaveOrders(imported);

                // 3. Загружаем из MSSQL и показываем в DataGrid
                _orders = _databaseService.GetAllOrders();
                OrdersGrid.ItemsSource = _orders;

                BtnExport.IsEnabled = true;
                SetStatus($"Импортировано {_orders.Count} записей из «{Path.GetFileName(dialog.FileName)}» → сохранено в MSSQL (Lab3DB.dbo.Orders).");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при импорте:\n\n{ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
                SetStatus("Ошибка импорта.");
            }
            finally
            {
                BtnImport.IsEnabled = true;
            }
        }

        // ──────────────────────────────────────────────────────────────────────
        //  ЭКСПОРТ В EXCEL
        // ──────────────────────────────────────────────────────────────────────

        private void BtnExport_Click(object sender, RoutedEventArgs e)
        {
            if (_orders.Count == 0)
            {
                MessageBox.Show("Сначала выполните импорт данных.", "Предупреждение",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var dialog = new SaveFileDialog
            {
                Title    = "Сохранить экспортированный файл",
                Filter   = "Excel файлы (*.xlsx)|*.xlsx",
                FileName = "export_by_date.xlsx"
            };

            if (dialog.ShowDialog() != true) return;

            try
            {
                SetStatus("Экспорт данных...");
                BtnExport.IsEnabled = false;

                _excelService.ExportGroupedByDate(_orders, dialog.FileName);

                SetStatus($"Экспорт завершён: «{Path.GetFileName(dialog.FileName)}» — каждая дата на отдельном листе.");

                var answer = MessageBox.Show("Экспорт выполнен успешно!\nОткрыть файл?",
                    "Готово", MessageBoxButton.YesNo, MessageBoxImage.Information);

                if (answer == MessageBoxResult.Yes)
                    System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo
                    {
                        FileName        = dialog.FileName,
                        UseShellExecute = true
                    });
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при экспорте:\n\n{ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
                SetStatus("Ошибка экспорта.");
            }
            finally
            {
                BtnExport.IsEnabled = true;
            }
        }

        private void SetStatus(string message) => StatusText.Text = message;
    }
}
