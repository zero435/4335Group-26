using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Lab3WPF.Models
{
    /// <summary>
    /// Модель таблицы Orders в MSSQL.
    /// Структура соответствует столбцам файла 3.xlsx.
    /// </summary>
    [Table("Orders")]
    public class Order
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)] // Id берём из Excel
        public int Id { get; set; }

        [Required]
        [MaxLength(50)]
        public string КодЗаказа { get; set; } = string.Empty;

        [Required]
        [MaxLength(20)]
        public string ДатаСоздания { get; set; } = string.Empty;

        [Required]
        [MaxLength(50)]
        public string КодКлиента { get; set; } = string.Empty;

        [Required]
        [MaxLength(200)]
        public string Услуги { get; set; } = string.Empty;
    }
}
