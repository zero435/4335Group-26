using System.Collections.Generic;
using System.Linq;
using Lab3WPF.Data;
using Lab3WPF.Models;

namespace Lab3WPF.Services
{
    /// <summary>
    /// Сервис для работы с MSSQL через Entity Framework Core.
    /// При первом запуске автоматически создаёт базу Lab3DB
    /// и таблицу Orders через EnsureCreated().
    /// </summary>
    public class DatabaseService
    {
        /// <summary>
        /// Создаёт базу данных и таблицу, если они не существуют.
        /// Вызывать один раз при старте приложения.
        /// </summary>
        public void EnsureDatabaseCreated()
        {
            using var db = new AppDbContext();
            // EnsureCreated создаёт БД и таблицы по модели,
            // если они ещё не существуют (без миграций).
            db.Database.EnsureCreated();
        }

        /// <summary>
        /// Очищает таблицу Orders и сохраняет новый список заказов.
        /// Используется при импорте из xlsx.
        /// </summary>
        public void SaveOrders(IEnumerable<Order> orders)
        {
            using var db = new AppDbContext();

            // Удаляем все существующие записи
            db.Orders.RemoveRange(db.Orders);
            db.SaveChanges();

            // Добавляем новые записи
            db.Orders.AddRange(orders);
            db.SaveChanges();
        }

        /// <summary>
        /// Возвращает все заказы из таблицы Orders, отсортированных по Id.
        /// </summary>
        public List<Order> GetAllOrders()
        {
            using var db = new AppDbContext();
            return db.Orders
                     .OrderBy(o => o.Id)
                     .ToList();
        }
    }
}
