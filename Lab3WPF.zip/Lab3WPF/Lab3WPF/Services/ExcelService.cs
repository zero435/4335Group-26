using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using Lab3WPF.Models;
using OfficeOpenXml;
using OfficeOpenXml.Style;

namespace Lab3WPF.Services
{
    /// <summary>
    /// Сервис для работы с Excel через EPPlus.
    /// Импорт: читает 3.xlsx (Id, Код заказа, Дата создания, Код клиента, Услуги).
    /// Экспорт: группирует по дате создания, каждая дата — отдельный лист.
    /// </summary>
    public class ExcelService
    {
        public ExcelService()
        {
            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
        }

        // ──────────────────────────────────────────────────────────────────────
        //  ИМПОРТ
        // ──────────────────────────────────────────────────────────────────────

        /// <summary>
        /// Читает данные из xlsx-файла и возвращает список заказов.
        /// Строка 1 — заголовки, данные с строки 2.
        /// </summary>
        public List<Order> ImportFromExcel(string filePath)
        {
            var orders = new List<Order>();

            using var package = new ExcelPackage(new FileInfo(filePath));
            var ws = package.Workbook.Worksheets[0];
            int rowCount = ws.Dimension?.Rows ?? 0;

            for (int row = 2; row <= rowCount; row++)
            {
                var idText = ws.Cells[row, 1].Text.Trim();
                if (string.IsNullOrEmpty(idText)) continue;

                orders.Add(new Order
                {
                    Id            = int.TryParse(idText, out var id) ? id : 0,
                    КодЗаказа    = ws.Cells[row, 2].Text.Trim(),
                    ДатаСоздания = ws.Cells[row, 3].Text.Trim(),
                    КодКлиента   = ws.Cells[row, 4].Text.Trim(),
                    Услуги       = ws.Cells[row, 5].Text.Trim()
                });
            }

            return orders;
        }

        // ──────────────────────────────────────────────────────────────────────
        //  ЭКСПОРТ
        // ──────────────────────────────────────────────────────────────────────

        /// <summary>
        /// Экспортирует заказы в новый xlsx-файл.
        /// Группировка по полю ДатаСоздания — каждая дата на отдельный лист.
        /// Формат листа (вариант 3):
        ///   Id | Код заказа | Код клиента | Услуги
        /// </summary>
        public void ExportGroupedByDate(List<Order> orders, string outputPath)
        {
            using var package = new ExcelPackage();

            var groups = orders
                .GroupBy(o => o.ДатаСоздания)
                .OrderBy(g => g.Key)
                .ToList();

            foreach (var group in groups)
            {
                // Имя листа: дату приводим к виду "01_10_2023"
                // (точки недопустимы в названии листа Excel)
                string sheetName = group.Key.Replace(".", "_");
                var ws = package.Workbook.Worksheets.Add(sheetName);

                // ── Строка-заголовок листа ────────────────────────────────────
                ws.Cells[1, 1].Value = $"Дата создания заказа: {group.Key}";
                ws.Cells[1, 1, 1, 4].Merge = true;
                ws.Cells[1, 1].Style.Font.Bold = true;
                ws.Cells[1, 1].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;

                // ── Заголовки столбцов (строка 2) ─────────────────────────────
                string[] headers = { "Id", "Код заказа", "Код клиента", "Услуги" };
                for (int col = 1; col <= headers.Length; col++)
                {
                    ws.Cells[2, col].Value = headers[col - 1];
                    ws.Cells[2, col].Style.Font.Bold = true;
                    ws.Cells[2, col].Style.Border.BorderAround(ExcelBorderStyle.Thin);
                    ws.Cells[2, col].Style.Fill.PatternType = ExcelFillStyle.Solid;
                    ws.Cells[2, col].Style.Fill.BackgroundColor.SetColor(Color.LightGray);
                }

                // ── Данные (с строки 3) ───────────────────────────────────────
                int dataRow = 3;
                foreach (var order in group)
                {
                    ws.Cells[dataRow, 1].Value = order.Id;
                    ws.Cells[dataRow, 2].Value = order.КодЗаказа;
                    ws.Cells[dataRow, 3].Value = order.КодКлиента;
                    ws.Cells[dataRow, 4].Value = order.Услуги;

                    for (int col = 1; col <= 4; col++)
                        ws.Cells[dataRow, col].Style.Border.BorderAround(ExcelBorderStyle.Thin);

                    dataRow++;
                }

                ws.Cells[ws.Dimension.Address].AutoFitColumns();
            }

            package.SaveAs(new FileInfo(outputPath));
        }
    }
}
